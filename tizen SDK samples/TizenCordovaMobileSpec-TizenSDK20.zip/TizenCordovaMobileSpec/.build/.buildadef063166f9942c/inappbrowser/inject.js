var d = document.getElementById("header")
d.innerHTML = "Script file successfully injected";
